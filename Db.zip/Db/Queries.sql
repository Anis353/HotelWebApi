﻿	use Hoteldb
	-- 1.	О клиентах, проживающих в заданном номере
	declare @number int = 3;

	select distinct
		 Client
		,Passport
		,FloorNumber
	from
		dbo.HistoryHotelAccommodationView
	where
		FloorNumber = @number;
	go


-- 2.	О клиентах, прибывших из заданного города
declare @city nvarchar(60) = 'Донецк';

select distinct
	HistoryHotelAccommodationView.Client
	, HistoryHotelAccommodationView.Passport
	,HistoryHotelAccommodationView.City
from
	HistoryHotelAccommodationView
where
	HistoryHotelAccommodationView.City = @city;
go

-- 3.	О том, кто из служащих убирал номер указанного клиента в заданный день недели
declare @passport nvarchar(15) = '11-32-212847', @dayOfWeek nvarchar(20) = 'Среда';

select distinct
	HistoryHotelAccommodationView.Client,
	HistoryHotelAccommodationView.Passport,
	HistoryHotelAccommodationView.City,
	HistoryHotelAccommodationView.RoomNumber,
	CleaningScheduleView.Employee,
	CleaningScheduleView.[DayOfWeek]

from
	HistoryHotelAccommodationView, CleaningScheduleView 
where 
	Passport = @passport and [DayOfWeek] = @dayOfWeek;
go
	    

-- 4.	Есть ли в гостинице свободные места и свободные номера и, если есть, то сколько и какие именно номера свободны.
declare @empty nvarchar(15) = 'Свободно';

select distinct
	HotelRoomsView.Number,
	HotelRoomsView.[Floor],
	HotelRoomsView.RoomType,
	HotelRoomsView.[State],
	HotelRoomsView.Price,
	HotelRoomsView.PhoneNumber
from 
	HotelRoomsView
where
	[State] = @empty;
go
	
